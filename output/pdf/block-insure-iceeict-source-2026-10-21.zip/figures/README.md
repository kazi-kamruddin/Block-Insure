# Figures for the selected six-page ICEEICT draft

Updated 21 October 2026. See the parent README for building and evidence scope.

| Paper figure | Asset | Status |
| --- | --- | --- |
| 1: Overall methodology | `methodology-overview.pdf` or `.png` | Author-supplied; reserved full-width slot, maximum 1.55-inch height |
| 2: Provider-risk comparison | `provider-risk-comparison.pdf` | Generated from recorded provider-model and bootstrap CSVs |
| 3: Controlled-attack routing | `controlled-attack-routing.pdf` | Generated from eight-scenario recorded recall CSV |
| 4: Reserve capital sweep | `reserve-capital-sweep.pdf` | Generated from the recorded phase-3 capital-grid JSON |

Each generated PDF has a 300-dpi PNG companion. The paper embeds the vector
PDFs. Regenerate with `../generate_figures.py`, not an application test command.
`figure-provenance.json` binds source filenames and hashes; no new empirical
results are implied by the presentation date.

The older pipeline PNGs and `../fig1.png` are retained historical/template
assets, not part of the revised build. Do not delete them just because the new
methodology slot is reserved for the author.
