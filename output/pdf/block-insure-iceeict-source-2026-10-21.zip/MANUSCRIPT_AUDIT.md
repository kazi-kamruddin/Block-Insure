# Selected manuscript audit

Review date: **21 October 2026**. This is an editorial and evidence audit of
the anonymous six-page ICEEICT working draft in `CSDE current`.

## Judgment and scope

The defensible contribution is the implemented separation of advisory risk,
external-record verification, human decisions, and funded settlement, evaluated
against different kinds of evidence. The revision makes that question visible
from the abstract through the conclusion. It does not establish a new consensus
algorithm, universal fraud accuracy, production reliability, or acceptance by
the conference. No new experiments were performed during this audit.

## Corrections applied

| Finding | Correction and supporting evidence |
| --- | --- |
| The abstract foregrounded broad metrics and implied operational feasibility. | Reframed around authority boundaries, representative execution, and explicit evidence limits. |
| The model/rule gain could appear to generalize across all eight attacks. | Frozen `paper-evidence/tables/controlled-attack-scenarios.csv` gives 6,160 additional detections, all in provider compromise; the other seven families already have 100% rules recall. Stated in abstract/results/conclusion and checked by the audit script. |
| Reserve `r` meant basis points in the treasury equation but a fraction in capital. | Defined fractional `rho = r/10000` consistently; checked against `PolicyEconomics.minimumTreasuryBalance` and the recorded reserve simulation. |
| `ES` could be read as the usual tail-risk measure. | Used conditional mean deficit notation and stated its shortfall conditioning. The simulation averages positive deficits. |
| Reserve scenarios lacked their defining parameter values in the manuscript. | Added baseline and stress frequency/severity, per-claim cap, deductible, and insurer share from the recorded phase-3 JSON. Severity stress changes both median and spread. |
| Procedure wording could imply computing routing after reveal or approving a matching negative verdict. | Placed worker checks before commit/reveal and specified matching positive observations for allocation. |
| Seven historical modules and nine current gas modules were easy to merge mentally. | Labeled August architecture/protocol/load versus October gas configuration directly in prose and captions. Historical coverage does not verify the current gas build. |
| The trust model was scattered across limitations. | Added a short explicit threat/assumption paragraph; oracle agreement remains application adjudication, with a shared operator and trusted registry/role administrators. |

## Evidence checked

- Numbered LaTeX sections, generated figures, bibliography and local audit tools.
- Frozen `paper-evidence/paper-metrics.json`, provider comparison/confidence CSVs,
  routing ablation/scenario CSVs, and the recorded verification summary.
- Recorded `backEnd/evaluation-results/phase3-reserve-evaluation.json` and the
  relevant reserve calculation and contract economics source.
- October `gas/local-gas-2026-10-21.json` receipts, row totals and source hashes;
  these remain single local observations with synthetic oracle inputs.
- Git status and existing changes; unrelated application files were preserved.

The main experimental evidence dates from **28–29 August 2026**, with the
**31 August** hardening follow-up. The latest included measurements are the
**21 October** local gas traces. The review date is not a new application-test
date. Existing source hashes, recorded results, and bounded assertions were
checked; the historical full application/ML studies were not independently rerun.
The existing DOI metadata record is retained; this audit adds no literature
or new publisher lookup and does not claim an exhaustive new literature review.

## Delivery checks

The final build is checked for six A4 pages, anonymous author block/metadata,
25 resolved and used bibliography entries, four figure positions, six tables,
embedded fonts, no Type-3 fonts, no overfull boxes, and conservative page bounds.
All six rendered pages receive visual inspection. The refreshed source ZIP is
compiled separately and compared with the selected manuscript. Exact results
and the PDF hash are in `revision-checks.json`.

Author-owned inputs remain the methodology figure, L1/L2 measurement evidence,
truthful LLM disclosure/policy resolution, and coauthor/submission decisions.
The reserved diagram and deployment cells remain deliberately incomplete;
`--submission` must continue to reject this working draft until those inputs
are resolved. No acceptance probability or claim of final submission readiness
is inferred from successful compilation.
