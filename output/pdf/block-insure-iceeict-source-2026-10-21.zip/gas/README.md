# Local receipts and pending network comparison

Measured **21 October 2026**; this supplements, rather than replaces, the August
experimental snapshot. `local-gas-2026-10-21.json` stores the exact git revision,
nine source/deployed-bytecode hashes, compiler settings, environment, 41 receipts
(including setup), and 11 manuscript row aggregates. The CSV is the presentation
extract. No real account keys or production records are used.

## What the local column means

- Ephemeral in-process Hardhat 2.29.1, chain 31337, Cancun, 100M block gas limit,
  Node 24.16.0, Solidity 0.8.26, IR, optimizer one run; exact settings in JSON.
- Seven deployment transactions create nine modules. `InsuranceManager` creates
  `OracleCoordinator` and `PolicyEconomics` in its constructor: their gas is
  already included, never added again. `ClaimAdjudicator` is deployed separately.
- Five other deployments are `PolicyBenefitsManager`, `EvidenceRegistry`,
  `ProtocolDeploymentRegistry`, `HospitalVerificationRegistry`, and
  `BankIdentityRegistry`. Their gas is aggregated in the auxiliary row.
- Configuration, grants, funding, package creation, identity registration, and
  baseline publication are setup receipts excluded from deployment totals.
- Both claims have a valid hospital attestation. Synthetic two-worker exact
  agreement produces either success or a negative oracle outcome. The second
  claim opens review and obtains three valid votes from its four-auditor snapshot.
- Both paths assert PAYOUT_READY, then SETTLED after claimant withdrawal, with
  allocated liability equal to withdrawn liability. These are scripted contract
  executions, not browser or real-worker end-to-end tests.
- Except for the manual-review row, operational values come from the automatic
  claim. The oracle row sums two commits and two reveals; the manual-review row
  sums opening review and three votes. It excludes the preceding negative oracle
  cycle. Do not add all table rows as a single lifecycle cost.
- Each operation has one observation; no variance or production-capacity claim
  follows. Storage history, calldata, timestamp, addresses, and compiler affect
  gas. The October manager is 24,338 bytes; August coverage/size results do not
  verify this newer build.

Reproduce from the repository root (requires the repository's contract dependencies):

```powershell
node contracts/scripts/runHardhat.js run "../reference/CSDE current/measure_local_gas.cjs" --network hardhat
```

The script refuses other networks, updates no live addresses/ABIs/environment,
and needs no wallet, database, browser, RPC subscription, or running local node.
Reproduction overwrites these local gas artifacts; use a separately dated copy
for a new measurement. Reconcile any new values in Table VI before rebuilding.

## L1/L2 inputs still needed from the author

Keep the same contract revision, compiler settings, deployment scope, claim input
shapes, roles, initial storage, and successful state transitions when comparing.
Record each target network name/chain ID, measurement date, transaction/block
hashes, deployed components, gasUsed, effective gas price, transaction status,
and total native-token fee. Keep deployment separate from setup transactions.

For L2, record the chain-specific total charged fee, including L1 data fees and
any operator fee; execution gas alone does not establish lower total cost.
Record the method/source for chain-specific fee fields. Public testnet fees
are testnet observations, not mainnet prices or money actually spent.

The paper currently compares **gas units** only. L1/L2 cells are null in JSON,
empty in CSV, and `--` in the paper. Name the chosen networks and explain fee
units before adding any monetary-cost claim. No public chain was contacted for
the local trace. An unmeasured network must never inherit the Hardhat value.

The historical 43,851 versus 11,402,190-gas comparison is a separate
`GasTestContract` registry-storage experiment (one root versus 500 hashes).
It is not contract-deployment or complete claim-lifecycle gas.
