"""Check the selected paper without executing the application or experiments.

python audit_paper.py          # local evidence / layout / citation checks
python audit_paper.py --doi    # additionally retrieve published DOI metadata
python audit_paper.py --submission  # fail if user-reserved work remains

DOI lookups send only public DOI identifiers, never manuscript text.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import unicodedata
import urllib.parse
import urllib.request

import pymupdf as fitz

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def bib_entries(text):
    starts = list(re.finditer(r"@\w+\s*\{\s*([^,]+),", text))
    result = {}
    for i, match in enumerate(starts):
        block = text[match.end():starts[i + 1].start() if i + 1 < len(starts) else len(text)]
        result[match[1].strip()] = block
    return result


def field(block, name):
    match = re.search(r"\b" + name + r"\s*=\s*\{", block, re.I)
    if not match:
        return None
    level, start = 1, match.end()
    for pos in range(start, len(block)):
        if block[pos] == "{" and (pos == 0 or block[pos - 1] != "\\"):
            level += 1
        if block[pos] == "}" and (pos == 0 or block[pos - 1] != "\\"):
            level -= 1
            if not level:
                return block[start:pos]
    raise ValueError(f"Unclosed BibTeX field: {name}")


def normalized_title(text):
    text = unicodedata.normalize("NFKD", text).casefold()
    return re.sub(r"[^a-z0-9]", "", text)


def check_doi(item):
    key, block = item
    doi = field(block, "doi")
    if not doi:
        return {"key": key, "status": "no_doi_assigned_in_existing_entry"}
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi, safe="/")
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "BlockInsure-BibliographyCheck/1.0"})
        with urllib.request.urlopen(request, timeout=25) as response:
            message = json.load(response)["message"]
        title = (message.get("title") or [""])[0]
        subtitle = (message.get("subtitle") or [""])[0]
        local_title = field(block, "title") or ""
        match = normalized_title(title) == normalized_title(local_title) or (
            subtitle and normalized_title(title + subtitle) == normalized_title(local_title))
        return {
            "key": key, "doi": doi, "status": "title_match" if match else "title_needs_review",
            "source": url, "localTitle": local_title, "registeredTitle": title,
            "registeredSubtitle": subtitle,
            "registeredAuthors": message.get("author", []),
            "registeredYear": message.get("published", message.get("issued", {})),
            "registeredVenue": message.get("container-title", []),
            "registeredVolume": message.get("volume"),
            "registeredIssue": message.get("issue"),
            "registeredPages": message.get("page"),
            "registeredArticleNumber": message.get("article-number"),
        }
    except Exception as error:
        return {"key": key, "doi": doi, "status": "unresolved", "detail": str(error)}


def local_checks():
    inputs = [HERE / "main.tex"] + sorted(HERE.glob("[0-9][0-9]_*.tex"))
    text = "\n".join(re.sub(r"(?<!\\)%[^\n]*", "", p.read_text(encoding="utf-8")) for p in inputs)
    entries = bib_entries((HERE / "references.bib").read_text(encoding="utf-8"))
    cited = {key.strip() for group in re.findall(r"\\cite\w*\{([^}]+)\}", text) for key in group.split(",")}
    labels = re.findall(r"\\label\{([^}]+)\}", text)
    referred = set(re.findall(r"\\(?:eqref|ref)\{([^}]+)\}", text))
    assert not (cited - entries.keys()), f"Missing bibliography keys: {cited - entries.keys()}"
    assert not (referred - set(labels)), f"Missing labels: {referred - set(labels)}"
    assert len(labels) == len(set(labels)), "Duplicate labels"
    assert len(re.findall(r"\\begin\{figure\*?\}", text)) == 4
    assert r"\newcommand{\methodologyheight}{1.55in}" in text
    assert r"\documentclass[conference,a4paper]{IEEEtran}" in text, "ICEEICT requires A4"
    assert r"\author{}" in text, "Initial review must have an anonymous author block"
    assert not re.search(r"\\tiny|\\fontsize", text), "Tiny manuscript text unexpectedly introduced"
    log = (HERE / "main.log").read_text(encoding="utf-8", errors="replace")
    assert not re.search(r"Overfull|undefined|multiply defined|Rerun to get|Missing character", log), "Resolve LaTeX diagnostics"
    pdf = fitz.open(HERE / "main.pdf")
    assert len(pdf) == 6, f"Expected six pages; found {len(pdf)}"
    body = "\n".join(page.get_text() for page in pdf)
    assert "??" not in body, "Unresolved reference visible in PDF"
    assert not re.search(r"Author Name|Institution Name|email-or-ORCID", body), "Remove author placeholders"
    assert not (pdf.metadata.get("author") or "").strip(), "Remove identifying PDF author metadata"
    assert (HERE / "main.pdf").stat().st_size <= 3_000_000, "Initial PDF exceeds 3 MB"
    outside = []
    for n, page in enumerate(pdf, 1):
        assert abs(page.rect.width - 595.28) < 1 and abs(page.rect.height - 841.89) < 1, "Expected A4 page dimensions"
        for word in page.get_text("words"):
            if word[0] < 30 or word[1] < 30 or word[2] > page.rect.width - 30 or word[3] > page.rect.height - 30:
                outside.append({"page": n, "word": word[4], "bbox": list(word[:4])})
    assert not outside, f"Words outside conservative page bounds: {outside[:5]}"
    fonts = {font[0]: font for page in pdf for font in page.get_fonts(full=True)}
    assert all(font[2] != "Type3" for font in fonts.values()), "Type-3 fonts need review"
    assert all(pdf.extract_font(xref)[3] for xref in fonts), "Unembedded PDF font"
    figure_manifest = json.loads((HERE / "figures/figure-provenance.json").read_text())
    for source in figure_manifest["sources"]:
        assert hashlib.sha256((ROOT / source["path"]).read_bytes()).hexdigest() == source["sha256"]
    with (ROOT / "paper-evidence/tables/controlled-attack-scenarios.csv").open(newline="") as handle:
        attacks = list(csv.DictReader(handle))
    assert sum(int(row["records"]) for row in attacks) == 54705
    additional_attacks = {
        row["scenario"]: round(int(row["records"]) *
                               (float(row["combined_recall"]) - float(row["rules_only_recall"])))
        for row in attacks
    }
    assert {key: count for key, count in additional_attacks.items() if count} == {"PROVIDER_COMPROMISE": 6160}
    assert "6,160" in body, "Keep the scenario-specific routing gain explicit"
    metrics = json.loads((ROOT / "paper-evidence/paper-metrics.json").read_text())
    assert metrics["dataset"]["testClaims"] == 109397
    assert metrics["dataset"]["runtimeRecords"] == 5000
    gas = json.loads((HERE / "gas/local-gas-2026-10-21.json").read_text())
    assert gas["chainId"] == 31337 and gas["samplesPerOperation"] == 1
    assert len(gas["modules"]) == 9
    assert len([row for row in gas["receipts"] if row["operation"].startswith("deploy:")]) == 7
    assert sum(int(row["gasUsed"]) for row in gas["receipts"] if row["operation"].startswith("deploy:")) == int(next(row["localGas"] for row in gas["rows"] if row["id"] == "deploy_total"))
    network_pending = False
    for row in gas["rows"]:
        table_row = re.search(r"^[^\n]*&\s*" + re.escape(f"{int(row['localGas']):,}") + r"\s*&([^\n]+)", text, re.M)
        assert table_row, f"Local gas missing from manuscript: {row['id']}"
        expected = ["--" if row[key] is None else f"{int(row[key]):,}" for key in ("l1Gas", "l2Gas")]
        observed = [cell.strip().removesuffix(r"\\").strip() for cell in table_row[1].split("&")]
        assert observed == expected, f"Network gas mismatch: {row['id']}"
        network_pending |= any(row[key] is None for key in ("l1Gas", "l2Gas"))
    for module in gas["modules"]:
        assert hashlib.sha256((ROOT / module["sourcePath"]).read_bytes()).hexdigest() == module["sourceSha256"], f"Gas snapshot source changed: {module['name']}"
    methodology_pending = "Reserved for the author-provided methodology diagram" in body
    disclosure_present = bool(re.search(r"\\section\*\{Acknowledg(?:e)?ment\}", text))
    remaining = []
    if methodology_pending:
        remaining.append("Author-provided methodology diagram")
    if network_pending:
        remaining.append("L1/L2 table measurements or an explicit editorial decision to remove pending columns")
    if not disclosure_present:
        remaining.append("Author-approved accurate LLM disclosure")
    return {
        "checkedAt": datetime.now(timezone.utc).isoformat(),
        "pageCount": len(pdf), "figureCountIncludingAuthorSlot": 4,
        "tableCount": len(re.findall(r"\\begin\{table\*?\}", text)),
        "authorFigureSlotHeightInches": 1.55, "generatedResultsFigures": 3,
        "citedKeys": len(cited), "bibliographyEntries": len(entries),
        "unusedBibliographyKeys": sorted(entries.keys() - cited),
        "crossReferencesResolved": True, "overfullBoxes": 0,
        "figureSourceHashesMatch": True, "bodyOrTableTinyFontOverrides": False,
        "additionalAttackDetections": additional_attacks,
        "newExperimentsRunDuringEditorialAudit": False,
        "outsidePageBounds": outside, "newExperimentsRun": True,
        "newExperimentScope": "Isolated current-source Hardhat deployment and two scripted gas paths only; August studies not rerun",
        "applicationEndToEndTested": False,
        "paperSize": "A4", "pdfBytes": (HERE / "main.pdf").stat().st_size,
        "anonymousAuthorBlock": True, "authorMetadataEmpty": True,
        "methodologyFigurePresent": not methodology_pending,
        "gasRowsWithLocalReceipts": len(gas["rows"]), "l1L2MeasurementsPending": network_pending,
        "acknowledgmentSectionPresent": disclosure_present,
        "allFontsEmbedded": True, "type3Fonts": 0,
        "applicationTested": False,
        "pdfSha256": hashlib.sha256((HERE / "main.pdf").read_bytes()).hexdigest(),
        "automatedSubmissionChecksPassed": not remaining,
        "submissionReady": False if remaining else None,
        "authorConfirmationsRequired": ["Conference LLM-policy eligibility and truthful disclosure",
                                        "Coauthor approval and CMT submission metadata"],
        "remainingAuthorInputs": remaining,
    }, entries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--doi", action="store_true")
    parser.add_argument("--submission", action="store_true", help="Fail while reserved author/submission inputs remain")
    parser.add_argument("--portable-dir", type=Path,
                        help="Compare a separately compiled extracted source package")
    args = parser.parse_args()
    result, entries = local_checks()
    if args.portable_dir:
        portable = fitz.open(args.portable_dir / "main.pdf")
        selected = fitz.open(HERE / "main.pdf")
        assert len(portable) == len(selected) == 6
        assert [page.get_text() for page in portable] == [page.get_text() for page in selected], "Portable build differs from selected manuscript"
        result["portableSourceCompiled"] = True
        result["portableSourceTextMatches"] = True
    (HERE / "revision-checks.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    if args.doi:
        cache_path = HERE / "bibliography-checks.json"
        cached = {}
        if cache_path.exists():
            cached = {item["key"]: item for item in json.loads(cache_path.read_text(encoding="utf-8"))["entries"]}
        results = []
        pending = []
        for key, block in entries.items():
            previous = cached.get(key)
            if previous and previous["status"] in {"title_match", "no_doi_assigned_in_existing_entry"} and previous.get("doi") == field(block, "doi") and (not previous.get("localTitle") or previous["localTitle"] == field(block, "title")):
                results.append(previous)
            else:
                pending.append((key, block))
        # Serialize retries rather than repeatedly hitting rate-limited records.
        with ThreadPoolExecutor(max_workers=1) as executor:
            results.extend(executor.map(check_doi, pending))
        report = {"checkedAt": datetime.now(timezone.utc).isoformat(), "method": "Public DOI identifiers queried against Crossref; metadata match is not a full-text claim audit", "entries": results}
        (HERE / "bibliography-checks.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        for item in results:
            print(item["key"], item["status"])
    if args.submission and not result["automatedSubmissionChecksPassed"]:
        raise SystemExit("Not submission-ready: " + "; ".join(result["remainingAuthorInputs"]))


if __name__ == "__main__":
    main()
