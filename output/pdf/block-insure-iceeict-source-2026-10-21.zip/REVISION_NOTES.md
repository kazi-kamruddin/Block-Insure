# Selected manuscript revision record

## Latest: evidence and editorial audit, 21 October 2026

- Preserved the preceding manuscript/PDF/tooling in
  `before-sensible-audit-2026-10-21.zip` before editing.
- Rewrote the abstract and research questions around explicit authority for
  advice, external verification, human adjudication, and funded settlement.
  Removed the unsupported universal claim about the absence of a public
  dataset and narrowed the operational-feasibility language.
- Calculated from the frozen scenario CSV that all 6,160 detections added by
  combined routing over rules come from the provider-compromise scenario.
  The abstract/results/conclusion now expose that concentration. This is an
  arithmetic derivation from existing evidence, not a new experiment.
- Added explicit threat assumptions and distinguished application-level
  oracle agreement from blockchain consensus. Kept the shared operator and
  trusted registry/role administrators visible. Corrected the procedure order
  so workers compute checks/routing before committing observations; matching
  positive observations, rather than any matching outcome, permit allocation.
- Corrected the reserve equations: `r` is the configured basis-point integer;
  `rho = r/10000` is the fraction used in simulated capital. Renamed the
  conditional mean deficit to avoid implying a quantile-based expected-shortfall
  risk measure. Included the actual frequency/severity/deductible/share settings
  so the reserve graph has interpretable experimental parameters.
- Marked Tables IV/V as August and Table VI as October, and identified each
  load level as a single batch. The seven- versus nine-module descriptions now
  have visible configuration labels. Updated the figures README's venue label.
- Kept all 25 references, three measured results figures, six tables, and the
  author's 1.55-inch methodology slot. L1/L2 values remain unmeasured.
- No application source changes, retraining, dataset regeneration, new gas
  measurement, browser regression, deployment, or Git commit in this audit.
  Verification and remaining author inputs are recorded in `MANUSCRIPT_AUDIT.md`
  and `revision-checks.json`.

## Earlier same-day: ICEEICT preparation, 21 October 2026

- Preserved the immediately preceding source, PDF, and checks in
  `before-iceeict-2026-10-21.zip`. Earlier baseline archives remain intact.
- Changed IEEEtran to A4, removed the author placeholder block, and explicitly
  emptied PDF author metadata for anonymous initial review. Author names belong
  in CMT at this stage. Checked visible text, metadata, and embedded link targets.
- Tightened contributions around the evaluated separation of risk advice,
  registry integrity, decision authority, and funded withdrawal. Kept provider
  risk separate from the 18-feature protocol model. Shortened repeated related
  work/discussion to preserve readable six-page layout with the new table.
- Clarified two-worker quorum, single-worker unavailability, shared operator
  trust, registry inclusion versus clinical truth, and valid-claim rejection
  caused by auditor abstention. The 11/50 local submission failures retain an
  explicitly unestablished root cause.
- Added Table VI with measured local deployment/operation gas and reserved L1/L2
  columns. The user will supply those network measurements; `--` means missing,
  not zero or an estimate. Deployment and registry-storage gas are distinct.
- Executed `measure_local_gas.cjs` on an ephemeral Hardhat chain (31337, Cancun,
  Hardhat 2.29.1, Node 24.16.0, 100M block gas limit). Seven deployment receipts
  create nine modules, including the two constructor modules. Forty-one receipts
  record setup plus purchase and automatic/manual claim paths; both assert
  PAYOUT_READY then SETTLED and the exact allocated/withdrawn liability. Setup
  gas is excluded from deployment totals. This is a new single-trace experiment
  dated 21 October, using synthetic observations; no browser, backend, database,
  Pinata, public RPC, or actual Oracle worker was exercised.
- New local evidence: `gas/local-gas-2026-10-21.json` and `.csv`, including source
  hashes, deployed-bytecode hashes, compiler settings, raw receipt gas, and row
  aggregates. Manager deployment 9,435,058 gas includes its coordinator/economics;
  seven-transaction deployment total is 16,801,639 gas. This excludes configuration
  and proves no public-network fee or deployment result. See `gas/README.md`.
- The current manager gas build is 24,338 deployed bytes; the manuscript's
  24,278-byte/298-byte-headroom value remains explicitly tied to 31 August.
  Archived model, routing, load, evidence, reserve, and assurance results are intact.
- Updated the audit for A4, the 3 MB limit, anonymous author block/metadata,
  source-bound gas rows, and explicit draft/submission checks. Missing diagram,
  L1/L2 data, and disclosure remain recorded; policy eligibility and coauthor
  approval require author confirmation. No invented disclosure was inserted.
- Recompiled six A4 pages, four figure positions (one reserved), six tables,
  and all 25 resolved references. All fonts embedded, no Type-3 fonts, no
  overfull boxes or text outside conservative bounds. Rendered pages inspected.
  Portable-source reproduction results are in `revision-checks.json`.
- Latest distribution: `output/pdf/block-insure-iceeict-anonymous-2026-10-21.pdf`
  and `output/pdf/block-insure-iceeict-source-2026-10-21.zip` (repository-relative).
  No application source was edited or Git commit made. The existing Explore
  files and earlier output artifacts are preserved.

## Historical: earlier same-day CSDE presentation overhaul

Review/presentation date: **21 October 2026**.
Experimental evidence: **28--29 August 2026**, with **31 August** contract
hardening/static-analysis follow-up. No new application tests or experimental
measurements were run for this revision.

### What changed

- Preserved the selected baseline in `baseline-before-overhaul-2026-10-21.zip`.
- Shortened the title to foreground authority-aware adjudication and the hybrid
  evaluation rather than claim classifier superiority.
- Reserved one full-width 1.55-inch-high methodology slot for the author, with
  automatic PDF/PNG insertion and a stable caption/label.
- Added three evidence-derived results figures with editable generation code,
  vector PDF assets, 300-dpi PNG companions, and source hashes.
- Distinguished the nine-feature provider-risk model from the separate
  18-feature claim/registry protocol model and their different label units.
- Added a compact version-bound adjudication procedure; kept the fixed four
  auditors, three-approval/two-rejection thresholds, funding boundary, and pull
  withdrawal explicit. This is pseudocode, not a formal proof.
- Replaced compressed tiny tables with five focused tables: dataset partitions,
  provider operating points, routing ablation, local protocol measurements, and
  local submission batches.
- Replaced the attack-scenario table with the complete eight-scenario heatmap;
  moved reserve findings into a capital-sweep plot and the explanatory text.
- Removed the empty public-network deployment rows and the coarse literature
  capability matrix; retained the cited related-work discussion. This avoids
  presenting missing measurements or absence-of-reporting as a demonstrated
  comparative advantage.
- Clarified that untouched routing rates and paired-cohort confusion counts
  have different denominators; neither is a fraud-conviction rate.
- Explicitly identified dated measurements and narrowed security/performance
  interpretations, including the reserve sampler's recorded normal approximation
  above aggregate frequency 30. No frozen result JSON, CSV, model, dataset, or application
  source was altered.
- Retained all 25 existing citations; bibliography/cross-reference checks and
  public DOI-title metadata checks are recorded separately.
- Updated the stale README, which incorrectly described an empty bibliography
  and an older three-placeholder scaffold.

### Numerical evidence map

Paths below are relative to the repository root.

| Claim or display | Primary recorded source |
| --- | --- |
| Provider ranking / operating points | `paper-evidence/tables/provider-model-comparison.csv` |
| BNB-only bootstrap uncertainty | `paper-evidence/tables/provider-confidence-intervals.csv` |
| Feature ablation interpretation | `paper-evidence/tables/provider-feature-group-ablation.csv` |
| Eight scenario counts / routing recall | `paper-evidence/tables/controlled-attack-scenarios.csv` |
| Original-cohort escalation / strategy metrics | `paper-evidence/tables/routing-ablation.csv`; `backEnd/scripts/evaluateHybridDataset.js` for cohort definitions |
| Reserve curves / assumptions / intervals | `backEnd/evaluation-results/phase3-reserve-evaluation.json` |
| Local load batches | `paper-evidence/tables/runtime-throughput.csv` |
| Registry storage gas | `paper-evidence/tables/registry-gas-comparison.csv` |
| AES-GCM document timings | `paper-evidence/tables/evidence-document-latency.csv` |
| Single-recipient PRE capsule timings | `paper-evidence/tables/evidence-proxy-reencryption.csv` |
| Dataset / workflow / proof / unit-test snapshot | `paper-evidence/paper-metrics.json` |
| Later coverage, hardened bytes, and Slither counts | `paper-evidence/slither-triage.md` (31 August) |

The 28 August freeze reports 24,262 deployed bytes / 314 bytes headroom and
93.77% statement / 65.07% branch coverage. The later hardening record reports
24,278 / 298 and 93.79% / 65.03%, as used in this selected manuscript. These
are separate recorded revisions, not silently reconciled identical builds.
Likewise, the PRE table explicitly labels the single-recipient measurement;
four-recipient measurements in other prose must not be substituted for it.

### Verification and remaining input

- LaTeX + BibTeX + stabilized references: compiled using local TeX Live 2026.
- Exported source ZIP independently extracted and compiled with LaTeX/BibTeX;
  its six-page text matches the selected manuscript without repository services.
- Six pages including references and the main-figure reservation.
- Four figure positions, three generated results figures, five tables.
- All 25 cited bibliography keys resolve; no unused entries or missing labels.
- Twenty DOI-bearing entries matched Crossref titles, accounting for registered
  subtitles. Five existing dataset/specification/proceedings entries have no
  DOI in this bibliography; that is not inherently a defect.
- Figure-source hashes verified; no overfull boxes or text outside conservative
  page bounds; all PDF fonts embedded, no Type-3 fonts. Final rendered pages
  were visually inspected. Ordinary justified
  text/table underfull-box diagnostics are not missing or clipped content.
- Research counts, bootstrap intervals, gas, and timing values remain dated
  observations, not verification of the current application checkout.

No numerical data collection is outstanding for these figures. The author must
supply the methodology image and final author information. The document still
contains an explicit methodology placeholder and author placeholders, so it is
not yet a submission-ready camera-ready file. Recompile and inspect after those
edits. The six-page limit includes the current author block; a larger final
author block or a taller requested diagram may require another layout pass.

No platform services, wallet, MongoDB, Oracle workers, or blockchain were started.
No Git commit was made; the pre-existing Explore scaffolding was not changed.
