param(
    [string]$TexBin = '',
    [switch]$RegenerateFigures
)

$ErrorActionPreference = 'Stop'

function Resolve-TexProgram([string]$Program) {
    if ($TexBin) {
        $candidate = Join-Path $TexBin "$Program.exe"
        if (-not (Test-Path -LiteralPath $candidate)) { throw "Missing compiler: $candidate" }
        return $candidate
    }
    return (Get-Command $Program -ErrorAction Stop).Source
}

$latexProgram = Resolve-TexProgram 'pdflatex'
$bibtexProgram = Resolve-TexProgram 'bibtex'
Push-Location $PSScriptRoot
try {
    if ($RegenerateFigures) {
        & python generate_figures.py
        if ($LASTEXITCODE -ne 0) { throw 'Figure generation failed; paper was not rebuilt.' }
    }
    & $latexProgram -interaction=nonstopmode -halt-on-error main.tex | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'First LaTeX pass failed; inspect main.log.' }
    & $bibtexProgram main | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'BibTeX failed; inspect main.blg.' }
    foreach ($pass in 1..2) {
        & $latexProgram -interaction=nonstopmode -halt-on-error main.tex | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "LaTeX stabilization pass $pass failed; inspect main.log." }
    }
    & python audit_paper.py
    if ($LASTEXITCODE -ne 0) { throw 'Paper checks failed; do not submit this build.' }
    Write-Host 'Built main.pdf: six A4 pages, anonymous author block, resolved references, evidence hashes checked.'
    Write-Host 'This is a working submission draft. Review revision-checks.json for reserved author inputs and pending L1/L2 data.'
}
finally {
    Pop-Location
}
