# Block-Insure selected manuscript: ICEEICT review preparation

Review revision: **21 October 2026**. The user-selected `CSDE current` folder
now contains the anonymous A4 ICEEICT working draft, based on the earlier
same-day CSDE revision. The separate expanded `../CSDE/` is not the selected draft.

The latest same-day editorial audit is recorded in `MANUSCRIPT_AUDIT.md`.
It sharpens the central authority question, corrects reserve-ratio notation,
identifies the single scenario responsible for the routing gain, and makes
the August/October configuration labels explicit. No new experiments were
run during this audit; the earlier October gas receipts remain the newest
measurements. `before-sensible-audit-2026-10-21.zip` preserves the preceding
manuscript and audit tools.

`main.tex` includes the numbered section files; `main.pdf` is the compiled
paper. The revision contains **six pages including all 25 references**, four
figure positions (one reserved for the author), six tables, and one compact
adjudication procedure. IEEEtran A4 body size and page margins are retained;
tables no longer use `\tiny` or the former 6.5-point override.

The original selected folder, including its PDF and source, is preserved in
`baseline-before-overhaul-2026-10-21.zip`. Original template files, legacy
figure assets, and `4926_BlockInsure_CSDE_draft.pdf` are retained, not silently
presented as the revised paper.

`before-iceeict-2026-10-21.zip` additionally preserves the immediately preceding
Letter-format manuscript/source/checks. The latest distribution artifacts are
`../../output/pdf/block-insure-iceeict-anonymous-2026-10-21.pdf` and
`../../output/pdf/block-insure-iceeict-source-2026-10-21.zip`.

The author block and PDF author metadata are empty for double-blind review.
Actual author information belongs in CMT; restore it in the paper only when the
venue requires a named/camera-ready version. No author identities were invented.

## Insert the author's methodology figure

Create either `figures/methodology-overview.pdf` (preferred vector format) or
`figures/methodology-overview.png`. The PDF takes precedence if both exist.
Recompile: `06_methodology.tex` automatically replaces the reserved box.

The slot spans the full text width with a maximum height of **1.55 inches
(39.4 mm)**, excluding its caption. Use a wide layout and legible labels at that
size; preserve the `\methodologyheight` setting unless the whole paper is
rechecked. The placeholder itself is not a completed methodology illustration.
The caption and figure label are already installed. The old pipeline PNGs
remain only as historical/source assets; they are not used in this build.

Recommended diagram branches:

1. Public claims -> provider-held-out training/calibration/test -> weak-label
   provider-risk evaluation (nine aggregate features).
2. Original/modified claim pairs -> separate 18-feature protocol model and
   integrity rules -> controlled-attack routing evaluation.
3. Sampled 5,000-record registry -> version-bound oracle/manual adjudication ->
   funded allocation -> claimant pull withdrawal.

Do not draw the provider classifier as the runtime decision authority or depict
Merkle inclusion as clinical truth.

## Generated results figures

`generate_figures.py` produces vector PDF and 300-dpi PNG versions of:

- `provider-risk-comparison`: recorded ROC-AUC and average precision; bootstrap
  error bars only where recorded, for BNB.
- `controlled-attack-routing`: eight-scenario model/rule/combined recall heatmap
  with the actual injected sample counts.
- `reserve-capital-sweep`: recorded synthetic capital-grid sweep; no fitted or
  invented intermediate measurements.

`figures/figure-provenance.json` records the exact source paths and SHA-256
hashes. Figure generation never starts the application, retrains models,
rebuilds datasets, or reruns experiments.

## Build and verify

Install Python requirements if missing:

```powershell
python -m pip install -r requirements-paper.txt
```

On the reviewed machine, the figure generator can already use its optional
local dependencies in `.paper-tools/python/`; these are ignored tooling, not
part of the manuscript/source package.

With TeX Live or MiKTeX programs on PATH, run from this folder:

```powershell
.\build_paper.ps1
```

To regenerate plots as well, add `-RegenerateFigures`. If TeX is not on PATH,
supply its executable directory, for example on the reviewed machine:

```powershell
.\build_paper.ps1 -TexBin 'E:\installed files\texLive install\texlive\2026\bin\windows'
```

The build runs LaTeX, BibTeX, two stabilization passes, and `audit_paper.py`.
The audit enforces six A4 pages, an anonymous author block/empty author metadata,
the 3 MB limit, four figure positions, resolved references, no overfull boxes,
page bounds, unchanged plot sources, and gas values matching recorded receipts.
It records `revision-checks.json`, including outstanding author inputs. A normal
build may pass while intentional draft placeholders remain; `python audit_paper.py
--submission` explicitly fails on those remaining items. Automation cannot certify
LLM-policy eligibility or coauthor approval. Visually inspect the rebuilt PDF after
every diagram, table, or layout change.

The exported source ZIP includes all assets needed to compile `main.tex` (for
example, on Overleaf). Plot regeneration and evidence-hash auditing require
the original repository's recorded evidence paths; they are not required for
ordinary LaTeX compilation of the portable source package.

Optional `python audit_paper.py --doi` checks public DOI metadata with Crossref;
it sends identifiers only, not manuscript content, and caches successful
checks. `bibliography-checks.json` is metadata evidence, not a full-text
literature-claim audit. Twenty existing DOI-bearing entries matched registered
titles (including subtitles); the other five entries have no DOI in the
existing bibliography. No DOI or source was invented.

## Evidence scope and outstanding author work

The original experimental package dates from **28--29 August 2026**; the
hardening/Slither follow-up is dated **31 August**. These recorded studies and
their plots were not rerun. A separate **21 October 2026** isolated current-source
Hardhat measurement supplies Table VI: seven deployment transactions create nine
modules; two scripted paths reach funded withdrawal. It uses Hardhat **2.29.1**,
whereas the August experiments report **2.28.0**. Source hashes and receipts live
in `gas/`; this is not a fresh browser/backend/oracle-worker regression. See
`gas/README.md` for exact scope and the network measurement checklist.

The August hardened manager's 24,278 bytes / 298-byte headroom is not substituted
into the older freeze (24,262 / 314) or the October gas build (24,338 / 238).
Each describes its own recorded revision; the new gas trace establishes neither
public-chain deployment nor historical coverage for the current source.

The three results figures have complete recorded values. At the user's request,
Table VI now reserves **L1 and L2 columns**, marked `-- = not measured`. Its local
values are measured gas units, not real ETH fees or estimates of public-network
performance. Target networks, receipts, and L2 data-cost accounting remain pending.

Remaining author-owned work: methodology diagram, L1/L2 measurements, truthful
LLM disclosure/policy resolution, coauthor approval, and CMT submission. The
acknowledgment remains unfilled rather than asserting that assistance was purely
editorial. Do not submit the intentionally incomplete draft as final. See
`REVISION_NOTES.md` for changes, checks, and the dated evidence map.
