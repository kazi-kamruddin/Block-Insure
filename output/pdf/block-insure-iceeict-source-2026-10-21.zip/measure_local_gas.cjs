/** Receipt-based research measurement; only the ephemeral Hardhat network.
 * node contracts/scripts/runHardhat.js run "../reference/CSDE current/measure_local_gas.cjs" --network hardhat
 * No application deployments, environment files, or ABIs are updated.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '../..');
const hre = require(path.join(root, 'contracts/node_modules/hardhat'));
const { ethers } = hre;
const { buildCommitment } = require(path.join(root, 'contracts/test/helpers/oracleCoordinator'));
const receipts = [];
const components = [];
const hash = (text) => ethers.keccak256(ethers.toUtf8Bytes(text));

async function record(operation, transaction) {
  let receipt;
  try { receipt = await (await transaction).wait(); }
  catch (error) { throw new Error(`${operation}: ${error.message}`); }
  assert.equal(receipt.status, 1, operation);
  receipts.push({ operation, gasUsed: receipt.gasUsed.toString(),
    transactionHash: receipt.hash, blockNumber: receipt.blockNumber });
}
async function deploy(name, ...args) {
  let contract;
  try { contract = await (await ethers.getContractFactory(name)).deploy(...args); }
  catch (error) { throw new Error(`deploy:${name}: ${error.message}`); }
  await record(`deploy:${name}`, contract.deploymentTransaction());
  return contract;
}
async function identify(name, contract) {
  const code = await ethers.provider.getCode(await contract.getAddress());
  const sourcePath = `contracts/contracts/${name}.sol`;
  components.push({ name, sourcePath,
    sourceSha256: crypto.createHash('sha256').update(fs.readFileSync(path.join(root, sourcePath))).digest('hex'),
    deployedBytes: (code.length - 2) / 2, deployedCodeKeccak256: ethers.keccak256(code) });
}

async function main() {
  assert.equal(hre.network.name, 'hardhat', 'Only the ephemeral Hardhat network is permitted');
  assert.equal((await ethers.provider.getNetwork()).chainId, 31337n);
  const [admin, user, oracle1, oracle2, hospital, ...otherSigners] = await ethers.getSigners();
  const auditors = otherSigners.slice(0, 4);
  const manager = await deploy('InsuranceManager');
  const address = await manager.getAddress();
  const adjudicator = await deploy('ClaimAdjudicator', address);
  const benefits = await deploy('PolicyBenefitsManager', address);
  const evidence = await deploy('EvidenceRegistry', address);
  const directory = await deploy('ProtocolDeploymentRegistry', hash('BLOCK_INSURE_V1'), hash('gas-measurement-manifest'));
  const hospitalRegistry = await deploy('HospitalVerificationRegistry', address, admin.address);
  const bank = await deploy('BankIdentityRegistry', address, admin.address);
  const coordinator = await ethers.getContractAt('OracleCoordinator', await manager.oracleCoordinator());
  const economics = await ethers.getContractAt('PolicyEconomics', await manager.policyEconomics());
  for (const [name, contract] of Object.entries({ InsuranceManager: manager, ClaimAdjudicator: adjudicator,
    PolicyBenefitsManager: benefits, EvidenceRegistry: evidence, ProtocolDeploymentRegistry: directory,
    HospitalVerificationRegistry: hospitalRegistry, BankIdentityRegistry: bank,
    OracleCoordinator: coordinator, PolicyEconomics: economics })) await identify(name, contract);

  await record('setup:adjudicator', manager.configureClaimAdjudicator(await adjudicator.getAddress()));
  await record('setup:hospital', coordinator.configureHospitalVerificationRegistry(await hospitalRegistry.getAddress()));
  for (const oracle of [oracle1, oracle2])
    await record('setup:oracleRole', manager.grantProjectRole(await manager.ORACLE_ROLE(), oracle.address));
  for (const auditor of auditors)
    await record('setup:auditorRole', manager.grantProjectRole(await manager.AUDITOR_ROLE(), auditor.address));
  await record('setup:consensus', coordinator.updateConsensusConfig(2, 25, 25));
  await record('setup:registry', coordinator.publishRegistrySnapshot(hash('synthetic-gas-registry'), 1, hash('schema-v1')));
  await record('setup:hospitalIdentity', hospitalRegistry.registerHospitalIdentity('HOSP-001', hospital.address));
  const premium = ethers.parseEther('0.01');
  await record('setup:package', manager.createPolicyPackage('Health Basic', 'HEALTH', premium, ethers.parseEther('1'), 365, 'HOSPITAL_BILL'));
  await record('purchasePolicy', manager.connect(user).purchasePolicy(1, { value: premium }));
  await record('setup:fund', manager.fundContract({ value: ethers.parseEther('2') }));

  async function cycle(label, verified) {
    const incident = await ethers.provider.getBlock('latest');
    const claimId = await manager.claimCounter();
    await record(`${label}:submitClaim`, manager.connect(user).submitClaim(1, ethers.parseEther('0.1'),
      incident.timestamp, 'HOSPITALIZATION', 'HOSP-001', hash(`invoice-${label}`), hash(`document-${label}`), `ipfs://synthetic-${label}`));
    await record(`${label}:hospitalAttestation`, hospitalRegistry.connect(hospital).submitHospitalVerification(claimId, true, hash(`attest-${label}`)));
    await record(`${label}:requestOracle`, manager.requestOracleVerification(claimId));
    const request = await coordinator.getRequestByClaimId(claimId);
    const resultHash = hash(`observation-${label}`);
    for (const [index, oracle] of [oracle1, oracle2].entries()) {
      await record(`${label}:commit${index + 1}`, coordinator.connect(oracle).commitOracleResult(request.requestId,
        buildCommitment(request, verified, resultHash, hash(`${label}-salt-${index}`))));
    }
    for (const [index, oracle] of [oracle1, oracle2].entries()) {
      await record(`${label}:reveal${index + 1}`, coordinator.connect(oracle).revealOracleResult(request.requestId,
        verified, resultHash, request.claimVersion, request.registryVersion, request.modelVersion, hash(`${label}-salt-${index}`)));
    }
    if (!verified) {
      await record(`${label}:openReview`, manager.sendToManualReview(claimId));
      const review = await adjudicator.getReview(claimId, await manager.claimVersion(claimId));
      assert.equal(review.auditors.length, 4);
      for (const [index, auditorAddress] of review.auditors.slice(0, 3).entries()) {
        const signer = auditors.find((auditor) => auditor.address.toLowerCase() === auditorAddress.toLowerCase());
        assert.ok(signer);
        await record(`${label}:vote${index + 1}`, manager.connect(signer).castVote(claimId, 1));
      }
    }
    assert.equal((await manager.getClaim(claimId)).status, 7n, 'PAYOUT_READY before withdrawal');
    const allocation = await adjudicator.allocatedSettlementWei(claimId);
    assert.ok(allocation > 0n);
    await record(`${label}:withdrawSettlement`, manager.connect(user).withdrawSettlement(claimId));
    assert.equal((await manager.getClaim(claimId)).status, 9n, 'SETTLED after withdrawal');
    assert.equal(await adjudicator.withdrawnSettlementWei(claimId), allocation);
  }
  await cycle('auto', true);
  await cycle('manual', false);
  const sum = (pattern) => receipts.filter((row) => pattern.test(row.operation))
    .reduce((total, row) => total + BigInt(row.gasUsed), 0n).toString();
  const rows = [
    ['deploy_manager', 'Manager + two constructor modules', sum(/^deploy:InsuranceManager$/)],
    ['deploy_adjudicator', 'Adjudicator', sum(/^deploy:ClaimAdjudicator$/)],
    ['deploy_auxiliary', 'Five auxiliary modules (sum)', sum(/^deploy:(?!InsuranceManager$|ClaimAdjudicator$)/)],
    ['deploy_total', 'Deployment total (7 transactions)', sum(/^deploy:/)],
    ['purchase_policy', 'Policy purchase', sum(/^purchasePolicy$/)],
    ['submit_claim', 'Claim submission', sum(/^auto:submitClaim$/)],
    ['hospital_attestation', 'Hospital attestation', sum(/^auto:hospitalAttestation$/)],
    ['request_oracle', 'Oracle request', sum(/^auto:requestOracle$/)],
    ['oracle_cycle', 'Two commits + two reveals (sum)', sum(/^auto:(commit|reveal)/)],
    ['manual_review', 'Open review + three votes (sum)', sum(/^manual:(openReview|vote)/)],
    ['withdraw_settlement', 'Pull withdrawal', sum(/^auto:withdrawSettlement$/)],
  ].map(([id, operation, localGas]) => ({ id, operation, localGas, l1Gas: null, l2Gas: null }));
  const revision = execFileSync('git', ['-c', `safe.directory=${root.replaceAll('\\', '/')}`, 'rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
  const result = { measuredAt: new Date().toISOString(), reviewDate: '2026-10-21', gitRevision: revision,
    evidenceScope: 'New isolated local gas measurements; not a rerun of the August evaluation',
    chainId: 31337, hardfork: hre.config.networks.hardhat.hardfork,
    blockGasLimit: hre.config.networks.hardhat.blockGasLimit, nodeVersion: process.version,
    hardhatVersion: require(path.join(root, 'contracts/node_modules/hardhat/package.json')).version,
    compiler: hre.config.solidity.compilers[0], samplesPerOperation: 1,
    setupTransactionsExcludedFromDeploymentTotal: true, simulatedOracleInputs: true,
    browserBackendAndWorkersNotExecuted: true, modules: components, receipts, rows,
    pending: ['L1 network and dated transaction receipts', 'L2 network, execution gas and total fee including data costs'],
    cautions: ['Gas units are not monetary fees.', 'Local gas does not establish public-chain deployability.',
      'Manager deployment includes constructor-created OracleCoordinator and PolicyEconomics.',
      'Five auxiliaries: PolicyBenefitsManager, EvidenceRegistry, ProtocolDeploymentRegistry, HospitalVerificationRegistry, BankIdentityRegistry.',
      'Non-review operations use the automatic path; review sum excludes the preceding failed oracle cycle.',
      'Rows do not constitute one additive end-to-end total.'] };
  const output = path.join(__dirname, 'gas');
  fs.mkdirSync(output, { recursive: true });
  fs.writeFileSync(path.join(output, 'local-gas-2026-10-21.json'), JSON.stringify(result, null, 2) + '\n');
  fs.writeFileSync(path.join(output, 'local-gas-2026-10-21.csv'),
    'id,operation,local_gas,l1_gas,l2_gas\n' + rows.map((row) => `${row.id},${row.operation},${row.localGas},,`).join('\n') + '\n');
  console.log(JSON.stringify({ measuredAt: result.measuredAt, modules: components.length, receipts: receipts.length, rows }, null, 2));
}
main().catch((error) => { console.error(error.message); process.exitCode = 1; });
