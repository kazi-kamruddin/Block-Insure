"""Render paper figures from recorded evidence; never rerun or alter experiments.

Requires Python 3.11+, matplotlib and numpy. Outputs vector PDF and 300-dpi PNG.
Run from any directory: python generate_figures.py
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
# Optional local installation stays inside the ignored manuscript folder.
LOCAL_TOOLS = HERE / ".paper-tools/python"
if LOCAL_TOOLS.is_dir():
    sys.path.insert(0, str(LOCAL_TOOLS))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np

ROOT = HERE.parents[1]
FIGURES = HERE / "figures"
TABLES = ROOT / "paper-evidence" / "tables"
RESERVE = ROOT / "backEnd/evaluation-results/phase3-reserve-evaluation.json"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 7,
    "axes.labelsize": 7, "axes.titlesize": 7.3,
    "xtick.labelsize": 7, "ytick.labelsize": 7,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .5, "savefig.facecolor": "white",
})


def rows(name: str) -> list[dict]:
    with (TABLES / name).open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def save(fig, name: str):
    # Fixed canvas dimensions make inclusion in a single IEEE column predictable.
    fig.savefig(FIGURES / f"{name}.pdf", metadata={
        "Title": name.replace("-", " "),
        "Subject": "Recorded Block-Insure evaluation; presentation revision 2026-10-21",
        "Creator": "generate_figures.py; no new experimental measurements",
        "CreationDate": None, "ModDate": None,
    })
    fig.savefig(FIGURES / f"{name}.png", dpi=300)
    plt.close(fig)


def provider_comparison():
    data = rows("provider-model-comparison.csv")
    intervals = {r["metric"]: r for r in rows("provider-confidence-intervals.csv")}
    labels = ["BNB (frozen)", "Majority", "Rule score", "Logistic", "Weighted LR"]
    fig, axes = plt.subplots(1, 2, sharey=True, figsize=(3.48, 1.85))
    fig.subplots_adjust(left=.285, right=.98, bottom=.22, top=.85, wspace=.26)
    positions = np.arange(len(data))
    for ax, key, metric, title, limit in zip(
        axes, ["roc_auc", "pr_auc"], ["rocAuc", "prAuc"],
        ["(a) ROC-AUC", "(b) PR-AUC (AP)"], [1, .5],
    ):
        values = np.array([float(r[key]) for r in data])
        ax.barh(positions, values, height=.56,
                color=["#145f70"] + ["#b2c7ce"] * 4, zorder=2)
        ci = intervals[metric]
        ax.errorbar(values[0], 0, xerr=[
            [values[0] - float(ci["lower"])],
            [float(ci["upper"]) - values[0]],
        ], fmt="none", color="black", capsize=2, linewidth=.8, zorder=3)
        for y, value in enumerate(values):
            # Keep the BNB value clear of its (especially wide PR-AUC) interval.
            x = value * .18 if y == 0 else value + limit * .025
            ax.text(x, y, f"{value:.3f}", va="center", fontsize=7,
                    color="white" if y == 0 else "#172c34", zorder=4)
        ax.set_xlim(0, limit * 1.15)
        ax.set_xticks([0, limit / 2, limit])
        ax.set_yticks(positions, labels)
        ax.set_title(title, pad=8)
        ax.grid(axis="x", color="#e5e7eb", linewidth=.5, zorder=0)
        ax.tick_params(axis="y", length=0)
        ax.set_xlabel("Score (higher is better)", fontsize=7)
    axes[0].invert_yaxis()
    save(fig, "provider-risk-comparison")


def routing_heatmap():
    data = rows("controlled-attack-scenarios.csv")
    names = {
        "BLACKLISTED_HOSPITAL": "Blacklisted provider",
        "CANCELLED_RECORD": "Cancelled record",
        "DATE_MISMATCH": "Date mismatch",
        "INFLATED_AMOUNT": "Inflated amount",
        "NEAR_DUPLICATE": "Near duplicate",
        "NOISY_RECORD": "Noisy record",
        "PROVIDER_COMPROMISE": "Provider compromise",
        "USED_INVOICE": "Used invoice",
    }
    keys = ["model_only_recall", "rules_only_recall", "combined_recall"]
    values = np.array([[float(r[k]) * 100 for k in keys] for r in data])
    assert sum(int(r["records"]) for r in data) == 54705
    assert np.all(values[:, 2] == 100)
    fig, ax = plt.subplots(figsize=(3.48, 2.30))
    fig.subplots_adjust(left=.535, right=.995, bottom=.035, top=.85)
    palette = LinearSegmentedColormap.from_list("routing", ["#f2f6f8", "#145f70"])
    ax.imshow(values, cmap=palette, vmin=0, vmax=100, aspect="auto")
    ax.set_xticks(range(3), ["Model\nonly", "Rules\nonly", "Combined"])
    ax.xaxis.tick_top()
    ax.set_yticks(range(len(data)), [
        f'{names[r["scenario"]]} ({int(r["records"]):,})' for r in data
    ], fontsize=7)
    ax.tick_params(axis="both", length=0, pad=4)
    for i in range(len(data)):
        for j in range(3):
            value = values[i, j]
            label = "100" if value == 100 else "0" if value == 0 else f"{value:.1f}"
            ax.text(j, i, label, ha="center", va="center", fontsize=7.2,
                    color="white" if value >= 55 else "#152d35")
    ax.set_xticks(np.arange(-.5, 3, 1), minor=True)
    ax.set_yticks(np.arange(-.5, len(data), 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=1.2)
    ax.tick_params(which="minor", length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    save(fig, "controlled-attack-routing")


def reserve_frontier():
    evidence = json.loads(RESERVE.read_text(encoding="utf-8"))
    assert evidence["methodology"]["periods"] == 5000
    assert evidence["methodology"]["seed"] == 410034
    fig, ax = plt.subplots(figsize=(3.48, 2.25))
    fig.subplots_adjust(left=.155, right=.975, bottom=.205, top=.79)
    colors = ["#145f70", "#b34923", "#65569c", "#324252"]
    markers = ["o", "s", "^", "D"]
    labels = ["Baseline", "High frequency", "Heavy tail", "Combined stress"]
    for scenario, color, marker, label in zip(evidence["scenarios"], colors, markers, labels):
        sweep = scenario["capitalSweep"]
        x = [100 * p["capitalRatio"] for p in sweep]
        y = [100 * p["shortfallProbability"] for p in sweep]
        ax.plot(x, y, color=color, marker=marker, markersize=3,
                linewidth=1, label=label, clip_on=False)
    ax.axhline(1, color="#565656", linewidth=.8, linestyle="--")
    ax.annotate("1% target", xy=(26, 1), xytext=(23, 15), fontsize=7,
                arrowprops={"arrowstyle": "-", "lw": .5, "color": "#565656"})
    ax.axvline(5, color="#9aa3a8", linewidth=.6, linestyle=":")
    ax.set_xlim(1, 31)
    ax.set_ylim(-1, 104)
    ax.set_xticks([2, 5, 8, 10, 15, 20, 30])
    ax.set_yticks([0, 25, 50, 75, 100])
    ax.set_xlabel("Capital / exposure (%)")
    ax.set_ylabel("Shortfall probability (%)")
    ax.grid(axis="y", color="#e5e7eb", linewidth=.5)
    ax.legend(loc="lower left", bbox_to_anchor=(-.13, 1.035), ncol=2,
              frameon=False, fontsize=7, handlelength=1.7,
              columnspacing=1.3, borderaxespad=0)
    save(fig, "reserve-capital-sweep")


def main():
    FIGURES.mkdir(exist_ok=True)
    provider_comparison()
    routing_heatmap()
    reserve_frontier()
    sources = [
        TABLES / "provider-model-comparison.csv",
        TABLES / "provider-confidence-intervals.csv",
        TABLES / "controlled-attack-scenarios.csv", RESERVE,
    ]
    manifest = {
        "presentationRevision": "2026-10-21",
        "newExperimentsRun": False,
        "sources": [{"path": str(p.relative_to(ROOT)).replace("\\", "/"),
                     "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],
        "figures": {
            "provider-risk-comparison": "Provider-held-out weak labels; BNB-only recorded bootstrap intervals",
            "controlled-attack-routing": "Eight injected scenarios; cell values are routing recall percentages",
            "reserve-capital-sweep": "Recorded synthetic capital sweep; straight lines connect tested grid points",
        },
    }
    (FIGURES / "figure-provenance.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("Rendered 3 evidence-derived figures as PDF and PNG; no experiment rerun.")


if __name__ == "__main__":
    main()
