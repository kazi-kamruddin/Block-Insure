# Block-Insure selected CSDE manuscript

Presentation revision: **21 October 2026**. This is the user-selected six-page
baseline, not the separate expanded manuscript in `../CSDE/`.

`main.tex` includes the numbered section files; `main.pdf` is the compiled
paper. The revision contains **six pages including all 25 references**, four
figure positions (one reserved for the author), five tables, and one compact
adjudication procedure. IEEEtran body size and page margins are unchanged;
tables no longer use `\tiny` or the former 6.5-point override.

The original selected folder, including its PDF and source, is preserved in
`baseline-before-overhaul-2026-10-21.zip`. Original template files, legacy
figure assets, and `4926_BlockInsure_CSDE_draft.pdf` are retained, not silently
presented as the revised paper.

## Insert the author's methodology figure

Create either `figures/methodology-overview.pdf` (preferred vector format) or
`figures/methodology-overview.png`. The PDF takes precedence if both exist.
Recompile: `06_methodology.tex` automatically replaces the reserved box.

The slot spans the full text width with a maximum height of **1.55 inches
(39.4 mm)**, excluding its caption. Use a wide layout and legible labels at that
size; preserve the `\methodologyheight` setting unless the whole paper is
rechecked. The placeholder itself is not a completed methodology illustration.
The caption and figure label are already installed. The old pipeline PNGs
remain only as historical/source assets; they are not used in this build.

Recommended diagram branches:

1. Public claims -> provider-held-out training/calibration/test -> weak-label
   provider-risk evaluation (nine aggregate features).
2. Original/modified claim pairs -> separate 18-feature protocol model and
   integrity rules -> controlled-attack routing evaluation.
3. Sampled 5,000-record registry -> version-bound oracle/manual adjudication ->
   funded allocation -> claimant pull withdrawal.

Do not draw the provider classifier as the runtime decision authority or depict
Merkle inclusion as clinical truth.

## Generated results figures

`generate_figures.py` produces vector PDF and 300-dpi PNG versions of:

- `provider-risk-comparison`: recorded ROC-AUC and average precision; bootstrap
  error bars only where recorded, for BNB.
- `controlled-attack-routing`: eight-scenario model/rule/combined recall heatmap
  with the actual injected sample counts.
- `reserve-capital-sweep`: recorded synthetic capital-grid sweep; no fitted or
  invented intermediate measurements.

`figures/figure-provenance.json` records the exact source paths and SHA-256
hashes. Figure generation never starts the application, retrains models,
rebuilds datasets, or reruns experiments.

## Build and verify

Install Python requirements if missing:

```powershell
python -m pip install -r requirements-paper.txt
```

On the reviewed machine, the figure generator can already use its optional
local dependencies in `.paper-tools/python/`; these are ignored tooling, not
part of the manuscript/source package.

With TeX Live or MiKTeX programs on PATH, run from this folder:

```powershell
.\build_paper.ps1
```

To regenerate plots as well, add `-RegenerateFigures`. If TeX is not on PATH,
supply its executable directory, for example on the reviewed machine:

```powershell
.\build_paper.ps1 -TexBin 'E:\installed files\texLive install\texlive\2026\bin\windows'
```

The build runs LaTeX, BibTeX, two stabilization passes, and `audit_paper.py`.
The audit enforces six pages, four figure positions, resolved bibliography and
cross-references, no overfull boxes, page bounds, and unchanged plot-source
hashes. It records results in `revision-checks.json`. Always visually inspect
the rebuilt PDF, especially after replacing the author block or main diagram.

The exported source ZIP includes all assets needed to compile `main.tex` (for
example, on Overleaf). Plot regeneration and evidence-hash auditing require
the original repository's recorded evidence paths; they are not required for
ordinary LaTeX compilation of the portable source package.

Optional `python audit_paper.py --doi` checks public DOI metadata with Crossref;
it sends identifiers only, not manuscript content, and caches successful
checks. `bibliography-checks.json` is metadata evidence, not a full-text
literature-claim audit. Twenty existing DOI-bearing entries matched registered
titles (including subtitles); the other five entries have no DOI in the
existing bibliography. No DOI or source was invented.

## Evidence scope and outstanding author work

The reported experimental package dates from **28--29 August 2026**; the
contract-hardening/Slither follow-up is dated **31 August 2026**. The October
revision replots and clarifies those records. It is not fresh verification of
the newer application. The later 24,278-byte/298-byte-headroom contract result
is not substituted into the older frozen metrics JSON, which retains its own
24,262-byte/314-byte-headroom measurement.

There are **no missing numerical placeholders** for the chosen three results
figures. No local platform run is required to fill them. Public-testnet
measurements were not available and the former empty deployment table was
removed rather than populated with guesses.

Before submission, the author must supply the methodology diagram, finalize
author/affiliation/contact fields in `00_title_authors.tex`, and check the
actual venue's formatting, anonymization, AI-use, and submission requirements.
The original author placeholders were not replaced with invented identities.
See `REVISION_NOTES.md` for the changes and evidence map.
