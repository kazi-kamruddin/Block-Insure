# CSDE paper revision record

Review/presentation date: **21 October 2026**.
Experimental evidence: **28--29 August 2026**, with **31 August** contract
hardening/static-analysis follow-up. No new application tests or experimental
measurements were run for this revision.

## What changed

- Preserved the selected baseline in `baseline-before-overhaul-2026-10-21.zip`.
- Shortened the title to foreground authority-aware adjudication and the hybrid
  evaluation rather than claim classifier superiority.
- Reserved one full-width 1.55-inch-high methodology slot for the author, with
  automatic PDF/PNG insertion and a stable caption/label.
- Added three evidence-derived results figures with editable generation code,
  vector PDF assets, 300-dpi PNG companions, and source hashes.
- Distinguished the nine-feature provider-risk model from the separate
  18-feature claim/registry protocol model and their different label units.
- Added a compact version-bound adjudication procedure; kept the fixed four
  auditors, three-approval/two-rejection thresholds, funding boundary, and pull
  withdrawal explicit. This is pseudocode, not a formal proof.
- Replaced compressed tiny tables with five focused tables: dataset partitions,
  provider operating points, routing ablation, local protocol measurements, and
  local submission batches.
- Replaced the attack-scenario table with the complete eight-scenario heatmap;
  moved reserve findings into a capital-sweep plot and the explanatory text.
- Removed the empty public-network deployment rows and the coarse literature
  capability matrix; retained the cited related-work discussion. This avoids
  presenting missing measurements or absence-of-reporting as a demonstrated
  comparative advantage.
- Clarified that untouched routing rates and paired-cohort confusion counts
  have different denominators; neither is a fraud-conviction rate.
- Explicitly identified dated measurements and narrowed security/performance
  interpretations, including the reserve sampler's recorded normal approximation
  above aggregate frequency 30. No frozen result JSON, CSV, model, dataset, or application
  source was altered.
- Retained all 25 existing citations; bibliography/cross-reference checks and
  public DOI-title metadata checks are recorded separately.
- Updated the stale README, which incorrectly described an empty bibliography
  and an older three-placeholder scaffold.

## Numerical evidence map

Paths below are relative to the repository root.

| Claim or display | Primary recorded source |
| --- | --- |
| Provider ranking / operating points | `paper-evidence/tables/provider-model-comparison.csv` |
| BNB-only bootstrap uncertainty | `paper-evidence/tables/provider-confidence-intervals.csv` |
| Feature ablation interpretation | `paper-evidence/tables/provider-feature-group-ablation.csv` |
| Eight scenario counts / routing recall | `paper-evidence/tables/controlled-attack-scenarios.csv` |
| Original-cohort escalation / strategy metrics | `paper-evidence/tables/routing-ablation.csv`; `backEnd/scripts/evaluateHybridDataset.js` for cohort definitions |
| Reserve curves / assumptions / intervals | `backEnd/evaluation-results/phase3-reserve-evaluation.json` |
| Local load batches | `paper-evidence/tables/runtime-throughput.csv` |
| Registry storage gas | `paper-evidence/tables/registry-gas-comparison.csv` |
| AES-GCM document timings | `paper-evidence/tables/evidence-document-latency.csv` |
| Single-recipient PRE capsule timings | `paper-evidence/tables/evidence-proxy-reencryption.csv` |
| Dataset / workflow / proof / unit-test snapshot | `paper-evidence/paper-metrics.json` |
| Later coverage, hardened bytes, and Slither counts | `paper-evidence/slither-triage.md` (31 August) |

The 28 August freeze reports 24,262 deployed bytes / 314 bytes headroom and
93.77% statement / 65.07% branch coverage. The later hardening record reports
24,278 / 298 and 93.79% / 65.03%, as used in this selected manuscript. These
are separate recorded revisions, not silently reconciled identical builds.
Likewise, the PRE table explicitly labels the single-recipient measurement;
four-recipient measurements in other prose must not be substituted for it.

## Verification and remaining input

- LaTeX + BibTeX + stabilized references: compiled using local TeX Live 2026.
- Exported source ZIP independently extracted and compiled with LaTeX/BibTeX;
  its six-page text matches the selected manuscript without repository services.
- Six pages including references and the main-figure reservation.
- Four figure positions, three generated results figures, five tables.
- All 25 cited bibliography keys resolve; no unused entries or missing labels.
- Twenty DOI-bearing entries matched Crossref titles, accounting for registered
  subtitles. Five existing dataset/specification/proceedings entries have no
  DOI in this bibliography; that is not inherently a defect.
- Figure-source hashes verified; no overfull boxes or text outside conservative
  page bounds; all PDF fonts embedded, no Type-3 fonts. Final rendered pages
  were visually inspected. Ordinary justified
  text/table underfull-box diagnostics are not missing or clipped content.
- Research counts, bootstrap intervals, gas, and timing values remain dated
  observations, not verification of the current application checkout.

No numerical data collection is outstanding for these figures. The author must
supply the methodology image and final author information. The document still
contains an explicit methodology placeholder and author placeholders, so it is
not yet a submission-ready camera-ready file. Recompile and inspect after those
edits. The six-page limit includes the current author block; a larger final
author block or a taller requested diagram may require another layout pass.

No platform services, wallet, MongoDB, Oracle workers, or blockchain were started.
No Git commit was made; the pre-existing Explore scaffolding was not changed.
