"""Check the selected paper without executing the application or experiments.

python audit_paper.py          # local evidence / layout / citation checks
python audit_paper.py --doi    # additionally retrieve published DOI metadata

DOI lookups send only public DOI identifiers, never manuscript text.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import unicodedata
import urllib.parse
import urllib.request

import pymupdf as fitz

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def bib_entries(text):
    starts = list(re.finditer(r"@\w+\s*\{\s*([^,]+),", text))
    result = {}
    for i, match in enumerate(starts):
        block = text[match.end():starts[i + 1].start() if i + 1 < len(starts) else len(text)]
        result[match[1].strip()] = block
    return result


def field(block, name):
    match = re.search(r"\b" + name + r"\s*=\s*\{", block, re.I)
    if not match:
        return None
    level, start = 1, match.end()
    for pos in range(start, len(block)):
        if block[pos] == "{" and (pos == 0 or block[pos - 1] != "\\"):
            level += 1
        if block[pos] == "}" and (pos == 0 or block[pos - 1] != "\\"):
            level -= 1
            if not level:
                return block[start:pos]
    raise ValueError(f"Unclosed BibTeX field: {name}")


def normalized_title(text):
    text = unicodedata.normalize("NFKD", text).casefold()
    return re.sub(r"[^a-z0-9]", "", text)


def check_doi(item):
    key, block = item
    doi = field(block, "doi")
    if not doi:
        return {"key": key, "status": "no_doi_assigned_in_existing_entry"}
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi, safe="/")
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "BlockInsure-BibliographyCheck/1.0"})
        with urllib.request.urlopen(request, timeout=25) as response:
            message = json.load(response)["message"]
        title = (message.get("title") or [""])[0]
        subtitle = (message.get("subtitle") or [""])[0]
        local_title = field(block, "title") or ""
        match = normalized_title(title) == normalized_title(local_title) or (
            subtitle and normalized_title(title + subtitle) == normalized_title(local_title))
        return {
            "key": key, "doi": doi, "status": "title_match" if match else "title_needs_review",
            "source": url, "localTitle": local_title, "registeredTitle": title,
            "registeredSubtitle": subtitle,
            "registeredAuthors": message.get("author", []),
            "registeredYear": message.get("published", message.get("issued", {})),
            "registeredVenue": message.get("container-title", []),
            "registeredVolume": message.get("volume"),
            "registeredIssue": message.get("issue"),
            "registeredPages": message.get("page"),
            "registeredArticleNumber": message.get("article-number"),
        }
    except Exception as error:
        return {"key": key, "doi": doi, "status": "unresolved", "detail": str(error)}


def local_checks():
    inputs = [HERE / "main.tex"] + sorted(HERE.glob("[0-9][0-9]_*.tex"))
    text = "\n".join(re.sub(r"(?<!\\)%[^\n]*", "", p.read_text(encoding="utf-8")) for p in inputs)
    entries = bib_entries((HERE / "references.bib").read_text(encoding="utf-8"))
    cited = {key.strip() for group in re.findall(r"\\cite\w*\{([^}]+)\}", text) for key in group.split(",")}
    labels = re.findall(r"\\label\{([^}]+)\}", text)
    referred = set(re.findall(r"\\(?:eqref|ref)\{([^}]+)\}", text))
    assert not (cited - entries.keys()), f"Missing bibliography keys: {cited - entries.keys()}"
    assert not (referred - set(labels)), f"Missing labels: {referred - set(labels)}"
    assert len(labels) == len(set(labels)), "Duplicate labels"
    assert len(re.findall(r"\\begin\{figure\*?\}", text)) == 4
    assert r"\newcommand{\methodologyheight}{1.55in}" in text
    assert not re.search(r"\\tiny|\\fontsize", text), "Tiny manuscript text unexpectedly introduced"
    log = (HERE / "main.log").read_text(encoding="utf-8", errors="replace")
    assert not re.search(r"Overfull|undefined|multiply defined|Rerun to get|Missing character", log), "Resolve LaTeX diagnostics"
    pdf = fitz.open(HERE / "main.pdf")
    assert len(pdf) == 6, f"Expected six pages; found {len(pdf)}"
    body = "\n".join(page.get_text() for page in pdf)
    assert "??" not in body, "Unresolved reference visible in PDF"
    outside = []
    for n, page in enumerate(pdf, 1):
        assert page.rect.width == 612 and page.rect.height == 792
        for word in page.get_text("words"):
            if word[0] < 35 or word[1] < 35 or word[2] > 577 or word[3] > 760:
                outside.append({"page": n, "word": word[4], "bbox": list(word[:4])})
    assert not outside, f"Words outside conservative page bounds: {outside[:5]}"
    fonts = {font[0]: font for page in pdf for font in page.get_fonts(full=True)}
    assert all(font[2] != "Type3" for font in fonts.values()), "Type-3 fonts need review"
    assert all(pdf.extract_font(xref)[3] for xref in fonts), "Unembedded PDF font"
    figure_manifest = json.loads((HERE / "figures/figure-provenance.json").read_text())
    for source in figure_manifest["sources"]:
        assert hashlib.sha256((ROOT / source["path"]).read_bytes()).hexdigest() == source["sha256"]
    with (ROOT / "paper-evidence/tables/controlled-attack-scenarios.csv").open(newline="") as handle:
        attacks = list(csv.DictReader(handle))
    assert sum(int(row["records"]) for row in attacks) == 54705
    metrics = json.loads((ROOT / "paper-evidence/paper-metrics.json").read_text())
    assert metrics["dataset"]["testClaims"] == 109397
    assert metrics["dataset"]["runtimeRecords"] == 5000
    return {
        "checkedAt": datetime.now(timezone.utc).isoformat(),
        "pageCount": len(pdf), "figureCountIncludingAuthorSlot": 4,
        "tableCount": len(re.findall(r"\\begin\{table\*?\}", text)),
        "authorFigureSlotHeightInches": 1.55, "generatedResultsFigures": 3,
        "citedKeys": len(cited), "bibliographyEntries": len(entries),
        "unusedBibliographyKeys": sorted(entries.keys() - cited),
        "crossReferencesResolved": True, "overfullBoxes": 0,
        "figureSourceHashesMatch": True, "bodyOrTableTinyFontOverrides": False,
        "outsidePageBounds": outside, "newExperimentsRun": False,
        "allFontsEmbedded": True, "type3Fonts": 0,
        "applicationTested": False,
        "pdfSha256": hashlib.sha256((HERE / "main.pdf").read_bytes()).hexdigest(),
        "remainingAuthorInputs": ["Methodology diagram", "Author/affiliation/contact details", "Venue submission checks"],
    }, entries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--doi", action="store_true")
    parser.add_argument("--portable-dir", type=Path,
                        help="Compare a separately compiled extracted source package")
    args = parser.parse_args()
    result, entries = local_checks()
    if args.portable_dir:
        portable = fitz.open(args.portable_dir / "main.pdf")
        selected = fitz.open(HERE / "main.pdf")
        assert len(portable) == len(selected) == 6
        assert [page.get_text() for page in portable] == [page.get_text() for page in selected], "Portable build differs from selected manuscript"
        result["portableSourceCompiled"] = True
        result["portableSourceTextMatches"] = True
    (HERE / "revision-checks.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    if args.doi:
        cache_path = HERE / "bibliography-checks.json"
        cached = {}
        if cache_path.exists():
            cached = {item["key"]: item for item in json.loads(cache_path.read_text(encoding="utf-8"))["entries"]}
        results = []
        pending = []
        for key, block in entries.items():
            previous = cached.get(key)
            if previous and previous["status"] in {"title_match", "no_doi_assigned_in_existing_entry"} and previous.get("doi") == field(block, "doi") and (not previous.get("localTitle") or previous["localTitle"] == field(block, "title")):
                results.append(previous)
            else:
                pending.append((key, block))
        # Serialize retries rather than repeatedly hitting rate-limited records.
        with ThreadPoolExecutor(max_workers=1) as executor:
            results.extend(executor.map(check_doi, pending))
        report = {"checkedAt": datetime.now(timezone.utc).isoformat(), "method": "Public DOI identifiers queried against Crossref; metadata match is not a full-text claim audit", "entries": results}
        (HERE / "bibliography-checks.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        for item in results:
            print(item["key"], item["status"])


if __name__ == "__main__":
    main()
